# HackRF Frequency Scanner

This script uses a HackRF device to scan a range of frequencies and detect FPV video signals.

## Features

- Scans a configurable frequency range
- Detects analog video signals
- Supports frequency table for channel identification
- Can capture and decode video frames
- Optional waterfall plot visualization

## Requirements

- HackRF device
- Python 3.6+
- Required Python packages:
  - numpy
  - scipy
  - matplotlib
  - pyyaml
  - opencv-python

## Configuration

Edit `config.json` to set your desired:
- Start and end frequencies
- Signal threshold
- Gain settings
- Video decoding parameters

Example configuration:
```json
{
    "start_frequency": 5700000000,
    "end_frequency": 5900000000,
    "dbm_threshold": -80,
    "gain": 20,
    "sample_rate": 16000000,
    "target_spl": 1017,
    "frame_width": 640,
    "frame_height": 480,
    "sync_threshold": 0.5,
    "min_sync_pulses": 5,
    "max_sync_deviation": 0.1,
    "video_bandwidth": 20000000,
    "video_center_freq": 5800000000,
    "video_gain": 20,
    "video_lna_gain": 16,
    "video_vga_gain": 20
}
```

## Usage

Basic usage:
```bash
sudo python hackrf_scanner.py
```

With frequency table:
```bash
sudo python hackrf_scanner.py --table
```

With custom configuration:
```bash
sudo python hackrf_scanner.py --config custom_config.json  # Use a different config file
```

Additional options:
- `--plot`: Show waterfall plot
- `--continuous`: Run continuously
- `--collect-time`: Set data collection time (seconds)
- `--frame-capture`: Enable video frame capture

## Frequency Table

The script can use a frequency table (`fpv_channels.txt`) to identify detected signals. The table should contain lines in the format:
```
BAND INDEX FREQ
```

Example:
```
A 1 5865
A 2 5845
A 3 5825
...
```

## Troubleshooting

If you encounter permission issues, make sure your user is in the `plugdev` group:
```bash
sudo usermod -a -G plugdev $USER
```

For video decoding issues, check that all required Python packages are installed:
```bash
pip install numpy scipy matplotlib pyyaml opencv-python
```
