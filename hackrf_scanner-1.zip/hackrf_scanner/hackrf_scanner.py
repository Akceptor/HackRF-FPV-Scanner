#!/usr/bin/env python3
"""
HackRF Frequency Scanner

This script uses a HackRF device to scan a range of frequencies and stops when
it detects a signal strength above a specified threshold.
"""

import sys
import time
import yaml
import argparse
import numpy as np
from scipy import signal
import matplotlib.pyplot as plt
from threading import Event
from subprocess import Popen, PIPE, STDOUT

def load_config(config_file):
    """Load configuration from YAML file."""
    try:
        with open(config_file, 'r') as f:
            config = yaml.safe_load(f)
        return config
    except Exception as e:
        print(f"Error loading config: {e}")
        sys.exit(1)

def parse_hackrf_sweep_output(line):
    """Parse a line of output from hackrf_sweep and extract frequency and power data."""
    try:
        parts = line.strip().split(', ')
        if len(parts) >= 7:  # Typical format from hackrf_sweep
            # Make sure this is a data line with frequency information
            # Skip lines that don't have valid frequency information
            if not parts[2].isdigit() or not parts[3].isdigit():
                return None, None
                
            date = parts[0]
            time_str = parts[1]
            hz_low = int(parts[2])
            hz_high = int(parts[3])
            hz_bin_width = float(parts[4])
            
            # Extract dBm values - they start from the 6th element
            try:
                dbm_values = [float(x) for x in parts[6:]]
                # Calculate frequencies for each bin
                freqs = np.linspace(hz_low, hz_high, len(dbm_values))
                return freqs, dbm_values
            except ValueError:
                # If conversion to float fails, this isn't a data line
                pass
    except Exception as e:
        # More detailed error information for debugging
        # Don't print for every line to avoid flooding output
        if line and any(x in line for x in ['error', 'fail', 'sweep', 'hackrf']):
            print(f"Parse error: {str(e)[:100]} for line: {line.strip()[:50]}...")
    
    return None, None

def scan_frequencies(config, stop_event=None, continuous_mode=False, collect_data=False, max_samples=100):
    """
    Scan frequencies using hackrf_sweep and stop when signal exceeds threshold.
    
    Args:
        config: Configuration dictionary
        stop_event: Threading event to signal when to stop
        continuous_mode: If True, continues scanning until manually stopped
        collect_data: If True, collect data for plotting even below threshold
        max_samples: Maximum number of frequency samples to collect
    
    Returns:
        If collect_data is True, returns a tuple of (freq_data, power_data, max_freq, max_power)
        Otherwise, returns a tuple of (max_freq, max_power) if signal above threshold is found
    """
    start_freq = config['start_frequency'] / 1e6  # Convert to MHz for hackrf_sweep
    end_freq = config['end_frequency'] / 1e6  # Convert to MHz for hackrf_sweep
    threshold = config['dbm_threshold']
    gain = config.get('gain', 20)
    
    # For 300 MHz range (2.2 GHz to 2.5 GHz), we need a larger bin width
    # The HackRF has a limit of 8184 FFT bins for the entire range
    # Using a value of 5000 kHz (5 MHz) which should be safe
    bin_size_khz = 5000  # Fixed at 5 MHz
    
    # Format frequency parameters as integers for hackrf_sweep
    start_freq_int = int(start_freq)
    end_freq_int = int(end_freq)
    
    cmd = [
        'hackrf_sweep',
        '-f', f"{start_freq_int}:{end_freq_int}",
        '-w', f"{bin_size_khz}",
        '-g', f"{gain}"
    ]
    
    # Only add the one-shot flag if not in continuous mode
    if not continuous_mode:
        cmd.append('-1')
    
    print(f"Starting HackRF sweep from {start_freq} MHz to {end_freq} MHz")
    print(f"Signal threshold: {threshold} dBm")
    print(f"Running command: {' '.join(cmd)}")
    
    process = Popen(cmd, stdout=PIPE, stderr=STDOUT, text=True, bufsize=1, universal_newlines=True)
    
    try:
        max_freq = None
        max_power = float('-inf')
        empty_count = 0  # Track empty lines for error detection
        
        # For data collection and plotting
        all_freqs = []
        all_powers = []
        
        line_count = 0
        print("Waiting for HackRF data...")
        
        for line in iter(process.stdout.readline, ''):
            line_count += 1
            
            # Print raw data occasionally for debugging
            if line_count <= 5 or line_count % 20 == 0:
                print(f"DEBUG: Raw line[{line_count}]: {line.strip()[:100]}")
            
            # Reset empty line counter when we get data
            if line.strip():
                empty_count = 0
            else:
                empty_count += 1
                if empty_count > 10:
                    print("No data received for several iterations. Is the HackRF connected?")
                    print("Note: hackrf_sweep might not be working properly or returning expected data format.")
                    if not continuous_mode:
                        break
                    empty_count = 0  # Reset counter and continue trying
                continue
                
            if stop_event and stop_event.is_set():
                break
                
            # Debug the raw line contents if it matches specific keywords
            if line.strip() and ('2200000000' in line or '2500000000' in line or 'MHz' in line):
                print(f"FREQUENCY DATA: {line.strip()[:150]}")
                
            freqs, powers = parse_hackrf_sweep_output(line)
            if freqs is not None and powers is not None:
                # Data collection for plotting
                if collect_data and len(freqs) > 0 and len(powers) > 0:
                    all_freqs.extend(freqs)
                    all_powers.extend(powers)
                
                print(f"PARSED DATA: Got {len(powers)} power values from {freqs[0]/1e6:.2f} to {freqs[-1]/1e6:.2f} MHz")
                # Find the maximum power in this sweep
                if len(powers) > 0:
                    sweep_max_idx = np.argmax(powers)
                    sweep_max_power = powers[sweep_max_idx]
                    sweep_max_freq = freqs[sweep_max_idx]
                    
                    # Update overall maximum if this is higher
                    if sweep_max_power > max_power:
                        max_power = sweep_max_power
                        max_freq = sweep_max_freq
                    
                    # Print more detailed information about the scan
                    print(f"Scanning: {freqs[0]/1e6:.2f}-{freqs[-1]/1e6:.2f} MHz | "
                          f"Max power: {sweep_max_power:.2f} dBm at {sweep_max_freq/1e6:.2f} MHz")
                    
                    # Print a simplified spectrum visualization
                    if len(powers) > 10:
                        # Create a simple ASCII spectrum visualization
                        print("Spectrum: ", end="")
                        for p in powers[::len(powers)//10][:10]:  # Sample 10 points
                            bars = int((p + 100) // 5)  # Normalize to positive range
                            print("█" * min(bars, 10), end=" ")
                        print(f" | Peak: {sweep_max_power:.1f} dBm")
                    
                    # Check if we've found a signal above threshold
                    if sweep_max_power > threshold:
                        print(f"\n*** SIGNAL DETECTED ***")
                        print(f"Frequency: {sweep_max_freq/1e6:.4f} MHz")
                        print(f"Power: {sweep_max_power:.2f} dBm")
                        
                        # If we're collecting data, return all data plus the peak
                        if collect_data:
                            return all_freqs, all_powers, sweep_max_freq, sweep_max_power
                        else:
                            return sweep_max_freq, sweep_max_power
    
    except KeyboardInterrupt:
        print("\nScan interrupted by user")
    except Exception as e:
        print(f"\nError during scanning: {e}")
        if continuous_mode:
            print("Attempting to continue...")
            return None, None
    finally:
        try:
            process.terminate()
            process.wait(timeout=5)
        except:
            try:
                process.kill()
            except:
                pass  # Process might already be gone
    
    # Return collected data if requested
    if collect_data:
        if all_freqs and all_powers:
            print(f"\nCollected {len(all_freqs)} data points across {start_freq}-{end_freq} MHz range")
        else:
            print("\nNo data points collected for plotting")
            # Return empty lists instead of None to avoid unpacking errors
            all_freqs = []
            all_powers = []
        return all_freqs, all_powers, max_freq, max_power
    
    # Standard operation mode
    if max_freq is not None:
        print(f"\nMaximum signal found: {max_power:.2f} dBm at {max_freq/1e6:.4f} MHz")
        print(f"(Did not exceed threshold of {threshold} dBm)")
        return max_freq, max_power  # Return the max values even if below threshold
    else:
        print("\nNo valid signals detected")
    
    return None, None

def plot_console(freqs, powers, config, width=80, height=20):
    """Create an ASCII plot of the spectrum for console output."""
    if not freqs or not powers or len(freqs) == 0 or len(powers) == 0:
        print("No data available for console plot")
        return
    
    # Convert frequencies to MHz
    freq_mhz = [f/1e6 for f in freqs]
    
    # Create frequency bins across the range
    min_freq = config['start_frequency']/1e6
    max_freq = config['end_frequency']/1e6
    num_bins = width - 10  # Leave space for labels
    
    # Create bins
    freq_bins = np.linspace(min_freq, max_freq, num_bins)
    power_bins = [float('-inf')] * num_bins  # Initialize with very low values
    
    # Assign powers to bins (taking the maximum in each bin)
    for f, p in zip(freq_mhz, powers):
        bin_idx = int((f - min_freq) / (max_freq - min_freq) * (num_bins-1))
        if 0 <= bin_idx < num_bins and p > power_bins[bin_idx]:
            power_bins[bin_idx] = p
    
    # Find min/max for scaling
    min_power = min([p for p in power_bins if p != float('-inf')] or [-100])
    max_power = max(power_bins)
    if min_power == float('-inf'):
        min_power = -100  # Default if no valid data
    
    # Ensure min_power and max_power are different
    if max_power - min_power < 5:
        min_power = max_power - 5
    
    # Create the ASCII plot
    print(f"\nSignal Strength vs Frequency ({min_freq:.0f}-{max_freq:.0f} MHz)")
    print(f"Power range: {min_power:.1f} to {max_power:.1f} dBm (threshold: {config['dbm_threshold']} dBm)")
    print("-" * width)
    
    # Draw the plot
    for h in range(height, 0, -1):
        # Calculate the power level for this row
        power_level = min_power + (max_power - min_power) * h / height
        
        # Print the power label on the y-axis
        if h == height:
            row = f"{max_power:6.1f} |" 
        elif h == 1:
            row = f"{min_power:6.1f} |"
        elif h == height // 2:
            mid_power = min_power + (max_power - min_power) / 2
            row = f"{mid_power:6.1f} |"
        else:
            row = "       |"
        
        # Draw the data points
        for i, power in enumerate(power_bins):
            if power == float('-inf'):
                row += " "  # No data
            elif power >= power_level:
                row += "█"  # Full block for points above this level
            elif i > 0 and power_bins[i-1] != float('-inf') and power_bins[i-1] >= power_level:
                row += "▄"  # Half block for transitions
            elif i < len(power_bins)-1 and power_bins[i+1] != float('-inf') and power_bins[i+1] >= power_level:
                row += "▄"  # Half block for transitions
            else:
                row += " "  # Empty for points below this level
                
        print(row)
    
    # Draw the x-axis
    print("       " + "-" * num_bins)
    
    # Draw the frequency labels
    x_labels = ""
    for i in range(5):
        pos = i * (num_bins - 1) // 4
        freq_val = min_freq + (max_freq - min_freq) * i / 4
        label = f"{freq_val:.0f}"
        x_labels += label + " " * (pos - len(x_labels))
    
    # Print x-axis labels with some spacing
    print("       " + x_labels + f"{max_freq:.0f}")
    print(" " * 7 + "Frequency (MHz)")
    print()

def plot_results(freq, power, config, all_freqs=None, all_powers=None):
    """Plot the detected signal."""
    # First, create ASCII plot for console viewing
    if all_freqs and len(all_freqs) > 0 and all_powers and len(all_powers) > 0:
        plot_console(all_freqs, all_powers, config)
    
    # Then create the matplotlib plot
    plt.figure(figsize=(12, 8))
    plt.axhline(y=config['dbm_threshold'], color='r', linestyle='--', label=f"Threshold ({config['dbm_threshold']} dBm)")
    
    # If we have a full frequency sweep, plot it
    if all_freqs and len(all_freqs) > 0 and all_powers and len(all_powers) > 0:
        # Convert to MHz for plotting
        freq_mhz = [f/1e6 for f in all_freqs]
        
        # Create heatmap-style plot by binning data
        freq_bins = np.linspace(config['start_frequency']/1e6, config['end_frequency']/1e6, 300)
        power_bins = {}
        
        # Group by frequency bin
        for f, p in zip(freq_mhz, all_powers):
            # Find nearest bin
            bin_idx = int((f - freq_bins[0]) / (freq_bins[-1] - freq_bins[0]) * (len(freq_bins)-1))
            if 0 <= bin_idx < len(freq_bins):
                bin_freq = freq_bins[bin_idx]
                if bin_freq not in power_bins:
                    power_bins[bin_freq] = []
                power_bins[bin_freq].append(p)
        
        # Calculate max power for each bin
        bin_freqs = []
        bin_powers = []
        for bin_freq, powers in power_bins.items():
            if powers:  # Skip empty bins
                bin_freqs.append(bin_freq)
                bin_powers.append(max(powers))  # Take max power in each bin
        
        # Sort by frequency
        sorted_data = sorted(zip(bin_freqs, bin_powers))
        if sorted_data:
            bin_freqs, bin_powers = zip(*sorted_data)
            
            # Plot the frequency sweep
            plt.plot(bin_freqs, bin_powers, 'b-', alpha=0.7, linewidth=1)
            plt.scatter(bin_freqs, bin_powers, color='b', marker='.', s=5, alpha=0.5, label="Frequency Sweep")
    
    # If we have a specific strong signal, highlight it
    if freq is not None and power is not None:
        plt.scatter(freq/1e6, power, color='r', marker='o', s=100, label="Peak Signal")
        plt.annotate(f"{power:.2f} dBm", (freq/1e6, power), 
                     xytext=(10, 10), textcoords='offset points', 
                     color='red', fontweight='bold')
    
    # Plot styling
    plt.title(f"HackRF Frequency Scan: {config['start_frequency']/1e6:.1f}-{config['end_frequency']/1e6:.1f} MHz")
    plt.xlabel('Frequency (MHz)')
    plt.ylabel('Power (dBm)')
    plt.grid(True, alpha=0.3)
    plt.legend()
    
    # Y-axis limits to focus on relevant signal range
    if all_powers and len(all_powers) > 0:
        plt.ylim([min(min(all_powers), -100), max(max(all_powers), config['dbm_threshold']) + 5])
    else:
        # Default range if no data
        plt.ylim([-100, config['dbm_threshold'] + 5])
    
    # Save the plot
    plot_file = 'frequency_scan.png'
    plt.savefig(plot_file)
    print(f"Plot saved to {plot_file}")
    plt.show()

def main():
    parser = argparse.ArgumentParser(description='HackRF Frequency Scanner')
    parser.add_argument('--config', default='config.yaml', help='Path to configuration file')
    parser.add_argument('--plot', action='store_true', help='Plot results if signal found')
    parser.add_argument('--continuous', action='store_true', 
                      help='Run in continuous mode until manually interrupted')
    parser.add_argument('--collect-time', type=int, default=30,
                      help='Time in seconds to collect data before plotting')
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    print("\n=== HackRF Frequency Scanner ===")
    print(f"Scanning range: {config['start_frequency']/1e6:.1f} MHz to {config['end_frequency']/1e6:.1f} MHz")
    print(f"Threshold: {config['dbm_threshold']} dBm | Gain: {config.get('gain', 20)}")
    
    try:
        # Data collection mode
        if args.plot:
            print(f"Collecting data for {args.collect_time} seconds before plotting...")
            collect_start_time = time.time()
            try:
                result = scan_frequencies(config, collect_data=True, max_samples=1000)
                
                # Handle the return values (might be 2 or 4 values depending on signal detection)
                if len(result) == 4:
                    all_freqs, all_powers, max_freq, max_power = result
                elif len(result) == 2:
                    max_freq, max_power = result
                    # Get empty lists if no signal was detected but we need to plot
                    all_freqs, all_powers = [], []
                else:
                    all_freqs, all_powers = [], []
                    max_freq, max_power = None, None
            except Exception as e:
                print(f"Error during data collection: {e}")
                all_freqs, all_powers = [], []
                max_freq, max_power = None, None
            
            # Always attempt to plot with whatever data we have
            # Even if all_freqs is empty, the plot_results function will handle it
            plot_results(max_freq, max_power, config, all_freqs, all_powers)
        else:
            # Standard mode - continuous
            print("Press Ctrl+C to stop scanning...\n")
            args.continuous = True
            
            # In continuous mode, keep scanning until interrupted
            if args.continuous:
                # Create a threading event that will never be set (for continuous operation)
                stop_event = Event()
                try:
                    print("Starting continuous scanning. Press Ctrl+C to stop.")
                    while True:  # Keep restarting the scan if it exits
                        # Scan frequencies in continuous mode, explicitly passing the continuous flag
                        scan_frequencies(config, stop_event, continuous_mode=True)
                        print("Restarting scan...")
                        time.sleep(1)  # Brief pause between restarts
                except KeyboardInterrupt:
                    print("\nScanning stopped by user")
            else:
                # Original single-scan behavior
                freq, power = scan_frequencies(config)
                
                # If signal was found and plotting is enabled
                if freq is not None and args.plot:
                    plot_results(freq, power, config)
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    main()
