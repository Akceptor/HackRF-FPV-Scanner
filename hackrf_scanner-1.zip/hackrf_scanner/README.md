# HackRF Frequency Scanner

This tool uses a HackRF device to scan a range of frequencies and stops when it detects a signal above a specified dBm threshold. The frequency range and threshold are configurable.

## Prerequisites

- A HackRF device connected to your computer
- Python 3.7+
- HackRF utilities (`hackrf_sweep` command) installed
- Required Python packages (see requirements.txt)

## Installation

1. Clone or download this repository
2. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Configuration

Edit `config.yaml` to set your desired:
- Frequency range (start and end frequencies in Hz)
- Signal strength threshold in dBm
- Scan settings (bin size, gain, sample rate)

Default configuration:
```yaml
start_frequency: 100000000  # 100 MHz
end_frequency: 1000000000   # 1 GHz
dbm_threshold: -30          # in dBm
bin_size: 100000            # 100 kHz steps
gain: 20                    # Receiver gain
sample_rate: 2000000        # 2 MHz sample rate
```

## Usage

Run the scanner with:

```bash
python hackrf_scanner.py
```

Additional options:
```bash
python hackrf_scanner.py --config custom_config.yaml  # Use a different config file
python hackrf_scanner.py --plot                       # Create a plot of detected signal
```

## How It Works

The tool uses the `hackrf_sweep` command line utility to scan the specified frequency range. It parses the output to extract frequency and power information. When a signal with power above the threshold is detected, the scanner stops and reports the frequency and signal strength.

## Output

When a signal is detected above the threshold, the script will output:
- The frequency where the signal was detected
- The power level in dBm
- Optionally, a plot of the detected signal if `--plot` is specified
