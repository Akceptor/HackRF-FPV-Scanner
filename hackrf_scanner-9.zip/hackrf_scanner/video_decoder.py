#!/usr/bin/env python3
"""
FPV Video Signal Decoder

This module captures and decodes analog FPV video signals using a HackRF device.
It can extract frames from NTSC/PAL/FPV video signals.
"""

import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
import cv2
from subprocess import Popen, PIPE, STDOUT
import tempfile

# --- Configuration --- 
DEFAULT_CONFIG = {
    # Capture settings
    "sample_rate": 16e6,       # Sample rate in Hz (16 MHz)
    "capture_duration": 0.05,  # Capture duration in seconds (Corrected for pseudo-realtime)
    "rf_gain": 40,           # RF gain (LNA)
    "if_gain": 40,           # IF gain (VGA)
    "bb_gain": 40,           # Baseband gain (Amp) (Increased back to 40)
    
    # Demodulation settings
    "demod_lp_cutoff_mhz": 4.0, # Low-pass filter cutoff for demodulation (MHz)
    "sync_threshold_std_factor": 0.7, # Factor of std dev below mean for sync detection (Increased)
    "sync_median_filter_width_ms": 0.1, # Width for median filter on sync pulses (ms) (Reverted)

    # Frame Extraction settings
    "aspect_ratio_correction": 0.8, # Factor to adjust line width for 4:3 aspect ratio
    "gaussian_blur_kernel": (3, 3), # Kernel size for Gaussian blur
    "clahe_clip_limit": 2.0,        # Clip limit for CLAHE contrast enhancement
    "clahe_tile_grid_size": (8, 8),   # Tile grid size for CLAHE
    "target_standard": "NTSC",      # Preferred standard ('NTSC' or 'PAL')
    "target_spl": 1017,           # Target Samples Per Line (determined from best result)
    "vsync_threshold_factor": 2.0   # Multiplier for expected line duration for VSync detection (Increased)
}
# ---------------------

def capture_raw_iq_data(frequency, config):
    """
    Capture raw IQ data from HackRF at the specified frequency.
    
    Args:
        frequency: Center frequency in Hz
        config: Dictionary containing capture parameters (sample_rate, duration, gains)
        
    Returns:
        Numpy array of complex IQ samples
    """
    sample_rate = config["sample_rate"]
    duration = config["capture_duration"]
    if_gain = config["if_gain"]
    bb_gain = config["bb_gain"]

    # Create a temporary file to store the raw data
    with tempfile.NamedTemporaryFile(delete=False, suffix='.raw') as temp_file:
        temp_filename = temp_file.name
    
    # Use hackrf_transfer to capture raw IQ data
    freq_mhz = frequency / 1e6
    cmd = [
        'hackrf_transfer',
        '-r', temp_filename,  # Receive mode with output file
        '-f', str(int(freq_mhz * 1e6)),  # Frequency in Hz
        '-s', str(int(sample_rate)),  # Sample rate
        '-n', str(int(sample_rate * duration)),  # Number of samples
        '-a', '1',  # Enable amp
        '-l', str(int(if_gain)),  # LNA gain (IF gain)
        '-g', str(int(bb_gain)),  # VGA gain (Baseband gain)
    ]
    
    print(f"Capturing IQ data at {freq_mhz:.2f} MHz with {sample_rate/1e6:.1f} Msps for {duration:.1f} seconds...")
    print(f"Command: {' '.join(cmd)}")
    
    try:
        process = Popen(cmd, stdout=PIPE, stderr=STDOUT)
        # Increase timeout slightly based on duration
        timeout = duration + 10 
        output, _ = process.communicate(timeout=timeout) 
        
        if process.returncode != 0:
            print(f"Error capturing IQ data: {output.decode('utf-8')}")
            if os.path.exists(temp_filename):
                os.unlink(temp_filename)
            return None
        
        # Read the raw IQ data
        raw_data = np.fromfile(temp_filename, dtype=np.int8)
        
        # Convert to complex IQ samples (I=even indices, Q=odd indices)
        iq_data = raw_data[::2] + 1j * raw_data[1::2]
        
        # Clean up the temporary file
        if os.path.exists(temp_filename):
            os.unlink(temp_filename)
        
        return iq_data
    
    except Exception as e:
        print(f"Error during capture: {e}")
        # Clean up the temporary file
        if os.path.exists(temp_filename):
            os.unlink(temp_filename)
        return None

def demodulate_am(iq_data, config):
    """
    Demodulate AM signal from IQ data (Envelope detection).
    
    Args:
        iq_data: Complex IQ samples
        config: Dictionary containing demodulation parameters.
        
    Returns:
        Demodulated waveform (normalized envelope).
    """
    sample_rate = config["sample_rate"]
    cutoff_mhz = config["demod_lp_cutoff_mhz"]

    # Calculate the magnitude (envelope) of the signal
    magnitude = np.abs(iq_data)
    
    # Normalize to [0, 1]
    min_mag, max_mag = np.min(magnitude), np.max(magnitude)
    if max_mag > min_mag:
        magnitude = (magnitude - min_mag) / (max_mag - min_mag)
    else:
        magnitude = np.zeros_like(magnitude) # Avoid division by zero if signal is flat
    
    # Apply a low-pass filter to remove noise
    # Normalize cutoff frequency to Nyquist frequency (sample_rate/2)
    cutoff_freq_normalized = (cutoff_mhz * 1e6) / (sample_rate / 2)  
    if cutoff_freq_normalized >= 1.0:
        cutoff_freq_normalized = 0.99  # Ensure it's less than 1
    elif cutoff_freq_normalized <= 0:
         cutoff_freq_normalized = 0.01 # Ensure it's greater than 0

    b, a = signal.butter(2, cutoff_freq_normalized) # Reduced filter order from 4 to 2
    filtered = signal.filtfilt(b, a, magnitude)
    
    # --- Sync detection removed, happens separately --- 
    # sync_threshold = np.percentile(filtered, 20) 
    # sync_pulses = filtered < sync_threshold
    # sync_filter_width_ms = config["sync_median_filter_width_ms"]
    # min_sync_width_samples = max(1, int(sample_rate * (sync_filter_width_ms / 1000.0)))
    # if min_sync_width_samples % 2 == 0:
    #     min_sync_width_samples += 1 
    # sync_pulses = signal.medfilt(sync_pulses.astype(float), kernel_size=min_sync_width_samples).astype(bool)
    
    return filtered # Return the filtered envelope

def extract_frame_fixed_sync(demodulated, sync_pulses, config, lines, fps, samples_per_line_override):
    """
    Extracts a video frame using a *fixed* samples_per_line value, attempting VSync detection.
    
    Args:
        demodulated: Demodulated waveform (e.g., from FM).
        sync_pulses: Boolean array indicating potential sync pulse locations.
        config: Dictionary containing processing parameters.
        lines: Number of lines per frame (525 for NTSC, 625 for PAL).
        fps: Frames per second (30 for NTSC, 25 for PAL).
        samples_per_line_override: The exact number of samples per line to use for reshaping.

    Returns:
        Grayscale image as a numpy array, or None if failed.
    """
    # sample_rate = config["sample_rate"] # Not needed directly here
    aspect_ratio_corr = config["aspect_ratio_correction"]
    blur_kernel = config["gaussian_blur_kernel"]
    clahe_clip = config["clahe_clip_limit"]
    clahe_grid = config["clahe_tile_grid_size"]
    vsync_enabled = config.get("vsync_detection_enabled", True) # Default to enabled
    vsync_factor = config.get("vsync_threshold_factor", 2.0) # Using the increased factor

    # Use the provided samples_per_line directly for frame size calculation
    samples_per_line = int(samples_per_line_override) 
    if samples_per_line <= 0:
        print(f"Warning: Invalid samples_per_line_override ({samples_per_line_override})")
        return None
    samples_per_frame = samples_per_line * lines

    # --- Vertical Sync Detection (Refined) --- 
    frame_start = 0 # Default start at beginning
    if vsync_enabled and sync_pulses is not None and np.sum(sync_pulses) >= 10: # Need more pulses for robust VSync
        sync_indices = np.where(sync_pulses)[0]
        line_lengths = np.diff(sync_indices)
        
        # Filter line_lengths to be near the expected target SPL *before* VSync search
        min_plausible_len = samples_per_line * 0.7
        max_plausible_len = samples_per_line * 1.3
        plausible_indices = np.where((line_lengths >= min_plausible_len) & (line_lengths <= max_plausible_len))[0]
        
        if len(plausible_indices) >= 2: # Need at least two plausible lines to detect a gap
            # Now look for VSync gap *within the plausible sync pulse timings*
            # Get the indices corresponding to the *start* of these plausible gaps
            plausible_sync_start_indices = sync_indices[plausible_indices]
            # Calculate gaps between these plausible sync pulses
            plausible_gaps = np.diff(plausible_sync_start_indices)

            vsync_gap_threshold = samples_per_line * vsync_factor 
            vsync_candidates = np.where(plausible_gaps > vsync_gap_threshold)[0]
            
            if len(vsync_candidates) > 0:
                # Start from the plausible sync pulse *after* the first long plausible gap
                # Index in plausible_indices corresponding to the start of the long gap
                first_long_gap_idx_in_plausible = vsync_candidates[0]
                # Index in sync_indices corresponding to the pulse *after* this long gap
                frame_start_sync_idx = plausible_indices[first_long_gap_idx_in_plausible] + 1

                if frame_start_sync_idx < len(sync_indices):
                    frame_start = sync_indices[frame_start_sync_idx]
                    print(f"  -> VSync detected using refined gaps, starting frame extraction at sample {frame_start}")
                else:
                    print("  -> Warning: VSync candidate found too close to the end of data.")
            else:
                print(f"  -> Warning: No VSync gap detected ({vsync_gap_threshold=}) among plausible line lengths ({len(plausible_gaps)} gaps examined). Starting from sample 0.")
        else:
             print(f"  -> Warning: Not enough plausible line lengths ({len(plausible_indices)}) found near SPL={samples_per_line} for VSync detection. Starting from sample 0.")
    elif vsync_enabled:
        print(f"  -> Warning: Not enough sync pulses ({np.sum(sync_pulses)}) for VSync detection, starting from sample 0.")
    # ---------------------------------------------
        
    # Ensure we have enough data for a full frame after the start point
    if frame_start + samples_per_frame > len(demodulated):
        print(f"Warning: Not enough data ({len(demodulated)} samples) for a full frame ({samples_per_frame} samples) starting at {frame_start} with {samples_per_line} samples/line.")
        return None

    # Extract one complete frame
    frame_data = demodulated[frame_start : frame_start + samples_per_frame]
    
    # Reshape into lines
    try:
        reshaped = frame_data.reshape((lines, samples_per_line))
    except ValueError as e:
        print(f"Error reshaping frame data: {e}. Shape was {frame_data.shape}, target ({lines}, {samples_per_line})")
        return None
    
    # Convert to image (adjust for aspect ratio)
    width = int(samples_per_line * aspect_ratio_corr)  
    height = lines
    
    # --- Add check for valid width --- 
    if width <= 0:
        print(f"Warning: Calculated frame width is invalid ({width}). Derived from samples_per_line={samples_per_line}")
        return None
    # ---------------------------------

    # Rescale to proper image dimensions
    image = cv2.resize(reshaped, (width, height), interpolation=cv2.INTER_LINEAR)
    
    # Normalize to 0-255 range for grayscale
    min_val, max_val = np.min(image), np.max(image)
    if max_val > min_val:
        image = ((image - min_val) / (max_val - min_val) * 255).astype(np.uint8)
    else:
        image = np.full_like(image, 128, dtype=np.uint8) # Mid-gray if flat

    # Apply image processing to enhance quality
    if blur_kernel and blur_kernel[0] > 0 and blur_kernel[1] > 0:
        image = cv2.GaussianBlur(image, blur_kernel, 0)
    
    clahe = cv2.createCLAHE(clipLimit=clahe_clip, tileGridSize=clahe_grid)
    image = clahe.apply(image)
    
    return image

def capture_fpv_frame(frequency, config):
    """
    Capture FPV signal, FM demodulate, detect sync, extract frame, and return the frame array.
    
    Args:
        frequency: Carrier frequency in Hz
        config: Dictionary containing capture and processing parameters
        
    Returns:
        Numpy array of the extracted frame (grayscale), or None.
    """
    t_start = time.time()
    # print(f"\nCapturing FPV video frame at {frequency/1e6:.2f} MHz using config...") # Less verbose
    
    # --- Capture IQ Data --- 
    t_capture_start = time.time()
    iq_data = capture_raw_iq_data(frequency, config)
    t_capture_end = time.time()
    # print(f" -> IQ Capture took: {t_capture_end - t_capture_start:.2f} seconds") # Less verbose
    
    if iq_data is None or len(iq_data) < 1000:
        # print("Failed to capture enough IQ data") # Less verbose
        return None # Return None
        
    # --- Detect Sync Pulses (Re-enabled) --- 
    t_sync_start = time.time()
    magnitude = np.abs(iq_data)
    min_mag, max_mag = np.min(magnitude), np.max(magnitude)
    if max_mag > min_mag:
        magnitude_normalized = (magnitude - min_mag) / (max_mag - min_mag)
    else:
        magnitude_normalized = np.zeros_like(magnitude)
    sync_pulses = detect_sync_pulses(magnitude_normalized, config) 
    t_sync_end = time.time()
    num_sync = np.sum(sync_pulses)
    # print(f" -> Sync Pulse Detection ({num_sync} pulses) took: {t_sync_end - t_sync_start:.2f} seconds") # Less verbose
    # --------------------------------------------------------------------

    # --- FM Demodulation --- 
    t_fm_demod_start = time.time()
    demodulated_fm = demodulate_fm(iq_data, config)
    t_fm_demod_end = time.time()
    # print(f" -> FM Demodulation took: {t_fm_demod_end - t_fm_demod_start:.2f} seconds") # Less verbose

    # --- Frame Extraction --- 
    # saved_file_path = None # Initialize - Not needed when returning array
    sample_rate = config["sample_rate"]
    target_standard = config.get("target_standard", "NTSC") # Default to NTSC
    target_spl = config.get("target_spl", None)             # Get target SPL from config

    if target_spl is None: # Calculate theoretical if not specified
        if target_standard == "NTSC":
            target_spl = int(sample_rate / (30 * 525))
        else: # Assume PAL
            target_spl = int(sample_rate / (25 * 625))

    # print(f"\n--- Attempting FM Frame Extraction ({target_standard}, Target SPL: {target_spl}) ---") # Less verbose
    
    lines, fps = (525, 30) if target_standard == "NTSC" else (625, 25)
    frame = extract_frame_fixed_sync(
        demodulated_fm, 
        sync_pulses, # Pass detected pulses
        config, 
        lines=lines, 
        fps=fps, 
        samples_per_line_override=target_spl
    )
    
    # --- Modification: Return frame array, don't save --- 
    # if frame is not None:
    #     save_path = f"{save_path_base}.png"
    #     try:
    #         cv2.imwrite(save_path, frame)
    #         saved_file_path = save_path # Store the path if save succeeds
    #         # print(f"    -> Saved: {save_path}") # Less verbose
    #     except Exception as e:
    #          print(f"    -> Error saving {save_path}: {e}")
    # else:
    #     # print("    -> Extraction failed.") # Less verbose
    
    # t_extract_end = time.time()
    # print(f" -> Target Extraction ({target_standard}/SPL={target_spl}) took: {t_extract_end - t_extract_start:.2f} seconds")
    # 
    # t_end = time.time()
    # print(f"\nTotal time for capture_fpv_frame: {t_end - t_start:.2f} seconds")
    
    # Return the frame array (or None)
    return frame

def detect_sync_pulses(magnitude, config):
    """
    Detects sync pulses from the signal magnitude.

    Args:
        magnitude: Normalized signal magnitude (envelope).
        config: Dictionary containing sync detection parameters.

    Returns:
        Boolean array indicating sync pulses.
    """
    sample_rate = config["sample_rate"]
    sync_filter_width_ms = config["sync_median_filter_width_ms"]
    
    # Use percentile threshold on the magnitude itself
    sync_threshold = np.percentile(magnitude, 15) # Try 15th percentile
    sync_pulses = magnitude < sync_threshold
    
    # Clean up sync pulses by removing noise
    # Ensure kernel size is odd
    min_sync_width_samples = max(1, int(sample_rate * (sync_filter_width_ms / 1000.0)))
    if min_sync_width_samples % 2 == 0:
        min_sync_width_samples += 1  # Make it odd
    sync_pulses_cleaned = signal.medfilt(sync_pulses.astype(float), kernel_size=min_sync_width_samples).astype(bool)
    
    return sync_pulses_cleaned

def demodulate_fm(iq_data, config):
    """
    Demodulate FM signal from IQ data.
    Calculates instantaneous frequency deviation.

    Args:
        iq_data: Complex IQ samples
        config: Dictionary containing parameters (currently unused for FM demod).

    Returns:
        FM demodulated waveform (normalized frequency deviation).
    """
    sample_rate = config["sample_rate"]
    cutoff_mhz = config["demod_lp_cutoff_mhz"]

    # Calculate phase difference between consecutive samples
    phase_diff = np.angle(iq_data[1:] * np.conj(iq_data[:-1]))
    
    # Unwrap phase jumps (from -pi to pi)
    unwrapped_phase_diff = np.unwrap(phase_diff)
    
    # --- Add Low-pass filtering --- 
    # Apply a low-pass filter to the frequency deviation signal
    cutoff_freq_normalized = (cutoff_mhz * 1e6) / (sample_rate / 2)
    if cutoff_freq_normalized >= 1.0:
        cutoff_freq_normalized = 0.99
    elif cutoff_freq_normalized <= 0:
         cutoff_freq_normalized = 0.01
    
    b, a = signal.butter(2, cutoff_freq_normalized) # Use same 2nd order filter
    filtered_freq_dev = signal.filtfilt(b, a, unwrapped_phase_diff)
    # ------------------------------

    # Normalize the filtered result 
    min_f, max_f = np.min(filtered_freq_dev), np.max(filtered_freq_dev)
    if max_f > min_f:
        demodulated_fm = (filtered_freq_dev - min_f) / (max_f - min_f)
    else:
        demodulated_fm = np.zeros_like(filtered_freq_dev) # Flat signal

    # Need to add back one sample to match original length for frame extraction?
    # Pad with the first value
    demodulated_fm = np.pad(demodulated_fm, (1, 0), mode='edge')

    return demodulated_fm

if __name__ == "__main__":
    # Use the default config defined at the top
    config = DEFAULT_CONFIG 

    if len(sys.argv) > 1:
        try:
            freq = float(sys.argv[1]) * 1e6  # Convert MHz to Hz
        except ValueError:
            print(f"Error: Invalid frequency provided: {sys.argv[1]}")
            sys.exit(1)
    else:
        # Default frequency if none provided (e.g., a common FPV channel)
        freq = 5800e6 # Example: 5.8 GHz Raceband channel 1
        print(f"No frequency provided, defaulting to {freq/1e6:.1f} MHz")
    
    print("Attempting live video feed...")
    print("Press 'q' in the video window to quit.")

    window_name = "FPV Feed"
    # Create a named window
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL) 
    # Set window to fullscreen (Commented out)
    # cv2.setWindowProperty(window_name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
    
    frame_count = 0
    start_loop_time = time.time()
    # Format frequency for display
    freq_display_text = f"Freq: {freq/1e6:.1f} MHz"
    exit_text = "Press Q to Exit"

    while True:
        loop_iter_start = time.time()
        frame = capture_fpv_frame(freq, config)
        
        if frame is not None:
            frame_count += 1
            # --- Add Overlays --- 
            # FPS counter
            current_time = time.time()
            elapsed_time = current_time - start_loop_time
            if elapsed_time > 0:
                 fps_est = frame_count / elapsed_time
                 cv2.putText(frame, f"FPS: {fps_est:.1f}", (10, 30), 
                             cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            # Frequency Display (Top Right)
            text_size, _ = cv2.getTextSize(freq_display_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
            text_x = frame.shape[1] - text_size[0] - 10 # 10px padding from right
            text_y = 30
            cv2.putText(frame, freq_display_text, (text_x, text_y), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            # Exit Text (Bottom Center)
            text_size, _ = cv2.getTextSize(exit_text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
            text_x = (frame.shape[1] - text_size[0]) // 2 # Centered horizontally
            text_y = frame.shape[0] - 20 # 20px padding from bottom
            cv2.putText(frame, exit_text, (text_x, text_y), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            # --------------------

            cv2.imshow(window_name, frame)
        # else: # Optional: Show a black screen or last good frame on failure?
            # pass 

        # Wait for 1ms - crucial for imshow to work & allows checking keys
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            print("'q' key pressed. Stopping video feed.")
            break

        # Check if the window was closed using the OS 'X' button
        try:
            # cv2.WND_PROP_VISIBLE returns 0.0 if the window is closed/destroyed
            if cv2.getWindowProperty(window_name, cv2.WND_PROP_VISIBLE) < 1:        
                print("Window closed via OS close button. Stopping video feed.")
                break
        except cv2.error:
             # Handle cases where the window might be destroyed before the check
             print("Window check failed (likely already closed). Stopping video feed.")
             break
        
        # Print loop time occasionally
        # if frame_count % 30 == 0 and frame_count > 0:
        #     loop_iter_end = time.time()
        #     print(f"Loop iteration time: {(loop_iter_end - loop_iter_start)*1000:.1f} ms")

    cv2.destroyAllWindows()
    print("Video feed stopped.")
