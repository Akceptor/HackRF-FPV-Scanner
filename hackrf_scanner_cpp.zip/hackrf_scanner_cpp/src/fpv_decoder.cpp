#include "fpv_decoder.hpp"
#include <iostream>
#include <algorithm>
#include <cmath>
#include <thread>
#include <chrono>

FPVDecoder::FPVDecoder(const Config& config) 
    : config_(config), current_frequency_(0) {
    std::cout << "FPVDecoder constructor called" << std::endl;
    hackrf_ = std::make_unique<HackRFCapture>();
    hackrf_->device = nullptr;
    hackrf_->is_running = false;
}

FPVDecoder::~FPVDecoder() {
    std::cout << "FPVDecoder destructor called" << std::endl;
    stop();
}

bool FPVDecoder::initialize() {
    std::cout << "Initializing HackRF..." << std::endl;
    return initHackRF();
}

bool FPVDecoder::initHackRF() {
    std::cout << "Calling hackrf_init()..." << std::endl;
    int result = hackrf_init();
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_init() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    std::cout << "Opening HackRF device..." << std::endl;
    result = hackrf_open(&hackrf_->device);
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_open() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    std::cout << "Setting sample rate to " << config_.sample_rate << " Hz..." << std::endl;
    result = hackrf_set_sample_rate(hackrf_->device, config_.sample_rate);
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_set_sample_rate() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    std::cout << "Setting VGA gain to " << config_.bb_gain << " dB..." << std::endl;
    result = hackrf_set_vga_gain(hackrf_->device, config_.bb_gain);
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_set_vga_gain() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    std::cout << "Setting LNA gain to " << config_.rf_gain << " dB..." << std::endl;
    result = hackrf_set_lna_gain(hackrf_->device, config_.rf_gain);
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_set_lna_gain() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    std::cout << "Starting RX..." << std::endl;
    result = hackrf_start_rx(hackrf_->device, rx_callback, this);
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_start_rx() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        return false;
    }

    hackrf_->is_running = true;
    std::cout << "HackRF initialized and running" << std::endl;
    return true;
}

void FPVDecoder::setFrequency(double frequency_hz) {
    std::cout << "Setting frequency to " << frequency_hz << " Hz..." << std::endl;
    int result = hackrf_set_freq(hackrf_->device, static_cast<uint64_t>(frequency_hz));
    if (result != HACKRF_SUCCESS) {
        std::cerr << "hackrf_set_freq() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
    }
    current_frequency_ = frequency_hz;
}

cv::Mat FPVDecoder::captureFrame() {
    auto function_start_time = std::chrono::steady_clock::now();

    if (!hackrf_->is_running) {
        std::cerr << "Capture not running" << std::endl;
        return cv::Mat();
    }

    auto iq_capture_start_time = std::chrono::steady_clock::now();
    //std::cout << "Capturing IQ data..." << std::endl;
    auto iq_data = captureIQData();
    auto iq_capture_end_time = std::chrono::steady_clock::now();
    auto iq_capture_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(iq_capture_end_time - iq_capture_start_time).count();
    
    if (iq_data.empty()) {
        //std::cerr << "No IQ data captured" << std::endl;
        return cv::Mat();
    }

    auto demod_start_time = std::chrono::steady_clock::now();
    //std::cout << "Demodulating FM..." << std::endl;
    auto demodulated = demodulateFM(iq_data);
    auto demod_end_time = std::chrono::steady_clock::now();
    auto demod_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(demod_end_time - demod_start_time).count();
    
    if (demodulated.empty()) {
        std::cerr << "FM demodulation failed" << std::endl;
        return cv::Mat();
    }

    auto sync_start_time = std::chrono::steady_clock::now();
    //std::cout << "Detecting sync pulses..." << std::endl;
    auto sync_pulses = detectSyncPulses(demodulated);
    auto sync_end_time = std::chrono::steady_clock::now();
    auto sync_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(sync_end_time - sync_start_time).count();
    
    if (sync_pulses.empty()) {
        //std::cerr << "No sync pulses detected" << std::endl;
        return cv::Mat();
    }

    // Use standard NTSC parameters
    int samples_per_line = 1017;  // Standard NTSC samples per line
    int lines = 525;  // Standard NTSC lines per frame

    auto extract_start_time = std::chrono::steady_clock::now();
    //std::cout << "Extracting frame..." << std::endl;
    auto frame = extractFrame(demodulated, sync_pulses, samples_per_line, lines);
    auto extract_end_time = std::chrono::steady_clock::now();
    auto extract_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(extract_end_time - extract_start_time).count();
    
    if (frame.empty()) {
        std::cerr << "Frame extraction failed" << std::endl;
        return cv::Mat();
    }

    auto process_start_time = std::chrono::steady_clock::now();
    //std::cout << "Processing frame..." << std::endl;
    auto processed_frame = processFrame(frame);
    auto process_end_time = std::chrono::steady_clock::now();
    auto process_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(process_end_time - process_start_time).count();

    auto function_end_time = std::chrono::steady_clock::now();
    auto function_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(function_end_time - function_start_time).count();

    // Log timings
    // std::cout << "captureFrame Time: " << function_duration_ms << "ms [IQ:" << iq_capture_duration_ms 
    //           << "ms Demod:" << demod_duration_ms << "ms Sync:" << sync_duration_ms 
    //           << "ms Extract:" << extract_duration_ms << "ms Process:" << process_duration_ms << "ms]" << std::endl;

    return processed_frame;
}

void FPVDecoder::stop() {
    if (hackrf_->device && hackrf_->is_running) {
        std::cout << "Stopping RX..." << std::endl;
        int result = hackrf_stop_rx(hackrf_->device);
        if (result != HACKRF_SUCCESS) {
            std::cerr << "hackrf_stop_rx() failed: " << hackrf_error_name(static_cast<hackrf_error>(result)) << std::endl;
        }
        hackrf_->is_running = false;
    }
}

int FPVDecoder::rx_callback(hackrf_transfer* transfer) {
    FPVDecoder* decoder = static_cast<FPVDecoder*>(transfer->rx_ctx);
    
    // Process the received samples
    std::vector<uint8_t> buffer(transfer->buffer, transfer->buffer + transfer->valid_length);
    
    // Convert IQ samples to complex numbers
    std::vector<std::complex<float>> iq_samples;
    iq_samples.reserve(buffer.size() / 2);
    
    for (size_t i = 0; i < buffer.size(); i += 2) {
        float i_sample = (buffer[i] - 127.5f) / 127.5f;
        float q_sample = (buffer[i + 1] - 127.5f) / 127.5f;
        iq_samples.emplace_back(i_sample, q_sample);
    }
    
    // Add samples to the buffer
    std::lock_guard<std::mutex> lock(decoder->hackrf_->buffer_mutex);
    decoder->hackrf_->buffer.insert(decoder->hackrf_->buffer.end(), iq_samples.begin(), iq_samples.end());
    
    return 0;
}

std::vector<std::complex<float>> FPVDecoder::captureIQData() {
    std::lock_guard<std::mutex> lock(hackrf_->buffer_mutex);
    if (hackrf_->buffer.empty()) {
        return std::vector<std::complex<float>>();
    }
    
    auto samples = std::move(hackrf_->buffer);
    hackrf_->buffer.clear();
    return samples;
}

std::vector<float> FPVDecoder::demodulateFM(const std::vector<std::complex<float>>& iq_data) {
    std::vector<float> demodulated;
    demodulated.reserve(iq_data.size() - 1);
    
    for (size_t i = 1; i < iq_data.size(); ++i) {
        float phase_diff = std::arg(iq_data[i] * std::conj(iq_data[i-1]));
        demodulated.push_back(phase_diff);
    }
    
    return demodulated;
}

std::vector<bool> FPVDecoder::detectSyncPulses(const std::vector<float>& signal) {
    std::vector<bool> pulses(signal.size(), false);
    float threshold = config_.sync_threshold;
    int min_width = config_.sync_min_width;
    
    for (size_t i = 0; i < signal.size(); ++i) {
        if (signal[i] > threshold) {
            int width = 1;
            while (i + width < signal.size() && signal[i + width] > threshold) {
                ++width;
            }
            if (width >= min_width) {
                std::fill(pulses.begin() + i, pulses.begin() + i + width, true);
                i += width;
            }
        }
    }
    
    return pulses;
}

cv::Mat FPVDecoder::extractFrame(const std::vector<float>& demodulated, 
                                const std::vector<bool>& sync_pulses,
                                int samples_per_line,
                                int lines) {
    cv::Mat frame(lines, samples_per_line, CV_8UC1);
    
    for (int i = 0; i < lines; ++i) {
        int start_idx = i * samples_per_line;
        if (start_idx + samples_per_line > demodulated.size()) {
            break;
        }
        
        for (int j = 0; j < samples_per_line; ++j) {
            float value = demodulated[start_idx + j];
            frame.at<uchar>(i, j) = static_cast<uchar>((value + M_PI) * 255.0 / (2.0 * M_PI));
        }
    }
    
    return frame;
}

cv::Mat FPVDecoder::processFrame(const cv::Mat& frame) {
    cv::Mat processed;
    frame.copyTo(processed);
    
    // Convert to color for OSD
    cv::cvtColor(processed, processed, cv::COLOR_GRAY2BGR);
    
    // Apply Gaussian blur
    cv::GaussianBlur(processed, processed, config_.gaussian_blur_kernel, 0);
    
    // Apply CLAHE
    cv::Ptr<cv::CLAHE> clahe = cv::createCLAHE(config_.clahe_clip_limit, config_.clahe_tile_grid_size);
    cv::Mat channels[3];
    cv::split(processed, channels);
    clahe->apply(channels[0], channels[0]);
    cv::merge(channels, 3, processed);
    
    // Add OSD overlay
    std::string freq_text = "Freq: " + std::to_string(current_frequency_ / 1e6) + " MHz";
    cv::putText(processed, freq_text, cv::Point(10, 30),
                cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);
    
    std::string gain_text = "Gain: LNA=" + std::to_string(config_.rf_gain) + 
                           "dB VGA=" + std::to_string(config_.bb_gain) + "dB";
    cv::putText(processed, gain_text, cv::Point(10, 60),
                cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);
    
    // Add signal status
    std::string status_text = "Status: " + std::string(hackrf_->is_running ? "Receiving" : "Stopped");
    cv::putText(processed, status_text, cv::Point(10, 90),
                cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);
    
    return processed;
} 