#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <opencv2/opencv.hpp>
#include "fpv_decoder.hpp"
#include <iomanip> // For std::fixed and std::setprecision

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <frequency_mhz> <band_name>" << std::endl;
        return 1;
    }

    double frequency_mhz = std::stod(argv[1]);
    std::string band_name = argv[2]; // Store the band name

    std::cout << "Initializing FPV decoder..." << std::endl;
    FPVDecoder::Config config; 
    FPVDecoder decoder(config);
    
    std::cout << "Configuring for frequency: " << frequency_mhz << " MHz, Band: " << band_name << std::endl;
    
    if (!decoder.initialize()) { 
        std::cerr << "Failed to initialize decoder" << std::endl;
        return 1;
    }

    std::cout << "Setting frequency..." << std::endl;
    decoder.setFrequency(frequency_mhz * 1e6); 

    std::cout << "Starting video capture..." << std::endl;

    std::cout << "Creating video window..." << std::endl;
    const std::string window_name = "FPV Video";
    cv::namedWindow(window_name, cv::WINDOW_NORMAL);
    cv::resizeWindow(window_name, 800, 600);

    std::cout << "Entering main processing loop..." << std::endl;
    auto last_frame_time = std::chrono::steady_clock::now();
    double fps = 0.0;
    int frame_count = 0;
    auto fps_update_time = last_frame_time;

    while (true) {
        auto loop_start_time = std::chrono::steady_clock::now();

        // Calculate time delta and FPS
        auto current_time = std::chrono::steady_clock::now();
        auto delta_time = std::chrono::duration_cast<std::chrono::microseconds>(current_time - last_frame_time).count();
        last_frame_time = current_time;
        
        // Update FPS every second for stability
        frame_count++;
        if (current_time - fps_update_time >= std::chrono::seconds(1)) {
            fps = frame_count / std::chrono::duration_cast<std::chrono::duration<double>>(current_time - fps_update_time).count();
            frame_count = 0;
            fps_update_time = current_time;
        }

        auto capture_start_time = std::chrono::steady_clock::now();
        cv::Mat frame = decoder.captureFrame(); 
        auto capture_end_time = std::chrono::steady_clock::now();
        auto capture_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(capture_end_time - capture_start_time).count();

        
        if (frame.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10)); 
            continue;
        }

        auto display_start_time = std::chrono::steady_clock::now();

        // Add FPS and Band Name to OSD (on the frame returned by the decoder)
        std::stringstream fps_ss;
        fps_ss << std::fixed << std::setprecision(1) << fps;
        std::string fps_text = "FPS: " + fps_ss.str();
        cv::putText(frame, fps_text, cv::Point(10, 120), 
                    cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);

        std::string band_text = "Band: " + band_name;
         cv::putText(frame, band_text, cv::Point(10, 150), 
                    cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);

        // Add capture time to OSD
        std::string capture_time_text = "Capture Time: " + std::to_string(capture_duration_ms) + " ms";
        cv::putText(frame, capture_time_text, cv::Point(10, 180), 
                    cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0, 255, 0), 2);

        cv::imshow(window_name, frame);
        auto display_end_time = std::chrono::steady_clock::now();
        auto display_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(display_end_time - display_start_time).count();

        int key = cv::waitKey(1) & 0xFF;
        if (key == 'q') {
            std::cout << "Quit requested..." << std::endl;
            break;
        }

        auto loop_end_time = std::chrono::steady_clock::now();
        auto loop_duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(loop_end_time - loop_start_time).count();
        // Optional: Log loop times if needed
        // std::cout << "Loop: " << loop_duration_ms << "ms, Capture: " << capture_duration_ms << "ms, Display: " << display_duration_ms << "ms" << std::endl;
    }

    std::cout << "Stopping capture..." << std::endl;
    decoder.stop(); 
    cv::destroyAllWindows();

    return 0;
} 