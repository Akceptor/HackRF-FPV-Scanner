#pragma once

#include <opencv2/opencv.hpp>
#include <hackrf.h>
#include <complex>
#include <vector>
#include <memory>
#include <string>
#include <mutex>

class FPVDecoder {
public:
    struct Config {
        double sample_rate;
        double capture_duration;
        int rf_gain;
        int if_gain;
        int bb_gain;
        
        double demod_lp_cutoff_mhz;
        double sync_threshold;
        int sync_min_width;
        
        double aspect_ratio_correction;
        cv::Size gaussian_blur_kernel;
        double clahe_clip_limit;
        cv::Size clahe_tile_grid_size;
        
        int max_no_signal_frames;
        double signal_timeout;

        Config() :
            sample_rate(16e6),
            capture_duration(0.02),
            rf_gain(40),
            if_gain(40),
            bb_gain(40),
            demod_lp_cutoff_mhz(4.0),
            sync_threshold(0.3),
            sync_min_width(5),
            aspect_ratio_correction(0.8),
            gaussian_blur_kernel(5, 5),
            clahe_clip_limit(3.0),
            clahe_tile_grid_size(8, 8),
            max_no_signal_frames(30),
            signal_timeout(5.0)
        {}
    };

    FPVDecoder(const Config& config = Config());
    ~FPVDecoder();

    bool initialize();
    void setFrequency(double frequency_hz);
    cv::Mat captureFrame();
    void stop();

private:
    struct HackRFCapture {
        hackrf_device* device;
        std::vector<std::complex<float>> buffer;
        std::mutex buffer_mutex;
        bool is_running;
    };

    Config config_;
    std::unique_ptr<HackRFCapture> hackrf_;
    double current_frequency_;
    
    bool initHackRF();
    std::vector<std::complex<float>> captureIQData();
    std::vector<float> demodulateFM(const std::vector<std::complex<float>>& iq_data);
    std::vector<bool> detectSyncPulses(const std::vector<float>& signal);
    cv::Mat extractFrame(const std::vector<float>& demodulated, 
                        const std::vector<bool>& sync_pulses,
                        int samples_per_line,
                        int lines);
    cv::Mat processFrame(const cv::Mat& frame);
    
    static int rx_callback(hackrf_transfer* transfer);
}; 