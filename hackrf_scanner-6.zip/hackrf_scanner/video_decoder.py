#!/usr/bin/env python3
"""
FPV Video Signal Decoder

This module captures and decodes analog FPV video signals using a HackRF device.
It can extract frames from NTSC/PAL/FPV video signals.
"""

import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
import cv2
from subprocess import Popen, PIPE, STDOUT
import tempfile

def capture_raw_iq_data(frequency, sample_rate=8e6, duration=1.0, gain=40, if_gain=40, bb_gain=40):
    """
    Capture raw IQ data from HackRF at the specified frequency.
    
    Args:
        frequency: Center frequency in Hz
        sample_rate: Sample rate in Hz (increased to 8 MHz for better video capture)
        duration: Capture duration in seconds
        gain: RF gain
        if_gain: IF gain
        bb_gain: Baseband gain
        
    Returns:
        Numpy array of complex IQ samples
    """
    # Create a temporary file to store the raw data
    with tempfile.NamedTemporaryFile(delete=False, suffix='.raw') as temp_file:
        temp_filename = temp_file.name
    
    # Use hackrf_transfer to capture raw IQ data
    freq_mhz = frequency / 1e6
    cmd = [
        'hackrf_transfer',
        '-r', temp_filename,  # Receive mode with output file
        '-f', str(int(freq_mhz * 1e6)),  # Frequency in Hz
        '-s', str(int(sample_rate)),  # Sample rate
        '-n', str(int(sample_rate * duration)),  # Number of samples
        '-a', '1',  # Enable amp
        '-l', str(int(if_gain)),  # LNA gain (IF gain)
        '-g', str(int(bb_gain)),  # VGA gain (Baseband gain)
    ]
    
    print(f"Capturing IQ data at {freq_mhz:.2f} MHz for {duration:.1f} seconds...")
    print(f"Command: {' '.join(cmd)}")
    
    try:
        process = Popen(cmd, stdout=PIPE, stderr=STDOUT)
        output, _ = process.communicate(timeout=duration+5)  # Wait for the process to complete
        
        if process.returncode != 0:
            print(f"Error capturing IQ data: {output.decode('utf-8')}")
            if os.path.exists(temp_filename):
                os.unlink(temp_filename)
            return None
        
        # Read the raw IQ data
        raw_data = np.fromfile(temp_filename, dtype=np.int8)
        
        # Convert to complex IQ samples (I=even indices, Q=odd indices)
        iq_data = raw_data[::2] + 1j * raw_data[1::2]
        
        # Clean up the temporary file
        if os.path.exists(temp_filename):
            os.unlink(temp_filename)
        
        return iq_data
    
    except Exception as e:
        print(f"Error during capture: {e}")
        # Clean up the temporary file
        if os.path.exists(temp_filename):
            os.unlink(temp_filename)
        return None

def demodulate_am(iq_data, sample_rate=8e6):
    """
    Demodulate AM signal from IQ data.
    FPV analog video typically uses AM modulation for the video signal.
    
    Args:
        iq_data: Complex IQ samples
        sample_rate: Sample rate in Hz
        
    Returns:
        Demodulated waveform and sync pulses
    """
    # Calculate the magnitude (envelope) of the signal
    magnitude = np.abs(iq_data)
    
    # Normalize to [0, 1]
    magnitude = (magnitude - np.min(magnitude)) / (np.max(magnitude) - np.min(magnitude))
    
    # Apply a low-pass filter to remove noise
    # For FPV video, we need to preserve frequencies up to about 4 MHz
    # Normalize cutoff frequency to Nyquist frequency (sample_rate/2)
    cutoff_freq = 4e6 / (sample_rate/2)  # This will be between 0 and 1
    if cutoff_freq >= 1.0:
        cutoff_freq = 0.99  # Ensure it's less than 1
    
    b, a = signal.butter(4, cutoff_freq)
    filtered = signal.filtfilt(b, a, magnitude)
    
    # Detect sync pulses using a more robust method
    # Calculate a moving average to establish the baseline
    window_size = int(sample_rate / 1000)  # 1ms window
    moving_avg = np.convolve(filtered, np.ones(window_size)/window_size, mode='same')
    
    # Find sync pulses as significant negative-going transitions
    sync_threshold = np.mean(moving_avg) - 0.2 * np.std(moving_avg)
    sync_pulses = filtered < sync_threshold
    
    # Clean up sync pulses by removing noise
    # Ensure kernel size is odd
    min_sync_width = int(sample_rate / 10000)  # Minimum sync pulse width
    if min_sync_width % 2 == 0:
        min_sync_width += 1  # Make it odd
    sync_pulses = signal.medfilt(sync_pulses.astype(float), kernel_size=min_sync_width).astype(bool)
    
    return filtered, sync_pulses

def extract_video_frame(demodulated, sync_pulses, sample_rate=8e6, lines=525, fps=30, ntsc=True):
    """
    Extract a video frame from a demodulated AM signal using sync pulses for alignment.
    
    Args:
        demodulated: Demodulated AM signal
        sync_pulses: Detected sync pulses
        sample_rate: Sample rate in Hz
        lines: Number of lines per frame (525 for NTSC, 625 for PAL)
        fps: Frames per second (30 for NTSC, 25 for PAL)
        ntsc: True for NTSC, False for PAL
        
    Returns:
        Grayscale image as a numpy array
    """
    # Calculate samples per line and frame
    samples_per_line = int(sample_rate / (fps * lines))
    samples_per_frame = samples_per_line * lines
    
    # Find the start of a frame using sync pulses
    sync_indices = np.where(sync_pulses)[0]
    if len(sync_indices) < 2:
        print("Warning: Not enough sync pulses detected")
        return None
    
    # Calculate the average line length from sync pulses
    line_lengths = np.diff(sync_indices)
    avg_line_length = np.median(line_lengths)
    
    # Find the start of a frame (vertical sync)
    # Look for a longer gap between sync pulses
    vsync_threshold = avg_line_length * 1.5
    vsync_indices = np.where(line_lengths > vsync_threshold)[0]
    
    if len(vsync_indices) == 0:
        print("Warning: No vertical sync detected")
        return None
    
    # Start from the first vertical sync
    frame_start = sync_indices[vsync_indices[0]]
    
    # Extract one complete frame
    frame_end = min(frame_start + samples_per_frame, len(demodulated))
    frame_data = demodulated[frame_start:frame_end]
    
    # Reshape into lines
    actual_lines = min(lines, len(frame_data) // samples_per_line)
    reshaped = np.resize(frame_data, (actual_lines, samples_per_line))
    
    # Convert to image (adjust for aspect ratio)
    # Typical analog TV aspect ratio is 4:3
    width = int(samples_per_line * 0.8)  # Adjust to avoid overscan
    height = actual_lines
    
    # Rescale to proper image dimensions
    image = cv2.resize(reshaped, (width, height))
    
    # Normalize to 0-255 range for grayscale
    image = ((image - np.min(image)) / (np.max(image) - np.min(image)) * 255).astype(np.uint8)
    
    # Apply image processing to enhance quality
    # First, apply a mild Gaussian blur to reduce noise
    image = cv2.GaussianBlur(image, (3, 3), 0)
    
    # Apply adaptive histogram equalization for better contrast
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    image = clahe.apply(image)
    
    # Apply a mild sharpening filter
    kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]]) / 9.0
    image = cv2.filter2D(image, -1, kernel)
    
    return image

def capture_fpv_frame(frequency, save_path="fpv_frame.png", duration=1.0):
    """
    Capture a single frame from an FPV video signal.
    
    Args:
        frequency: Carrier frequency in Hz
        save_path: Path to save the captured frame
        duration: Duration to capture in seconds
        
    Returns:
        Path to saved frame if successful, None otherwise
    """
    print(f"\nCapturing FPV video frame at {frequency/1e6:.2f} MHz...")
    
    # Capture raw IQ data with adjusted gain settings
    # Higher gain values for better signal capture
    iq_data = capture_raw_iq_data(
        frequency,
        duration=duration,
        gain=40,      # RF gain
        if_gain=40,   # IF gain
        bb_gain=40    # Baseband gain
    )
    
    if iq_data is None or len(iq_data) < 1000:
        print("Failed to capture enough IQ data")
        return None
    
    # Demodulate the signal
    demodulated, sync_pulses = demodulate_am(iq_data)
    
    # Try to extract a frame
    # Try both NTSC and PAL parameters
    frame_ntsc = extract_video_frame(demodulated, sync_pulses, ntsc=True)
    frame_pal = extract_video_frame(demodulated, sync_pulses, lines=625, fps=25, ntsc=False)
    
    if frame_ntsc is None and frame_pal is None:
        print("Failed to extract video frame")
        return None
    
    # Create a composite image with both attempts
    if frame_ntsc is not None and frame_pal is not None:
        height, width = frame_ntsc.shape
        composite = np.zeros((height*2, width), dtype=np.uint8)
        composite[:height, :] = frame_ntsc
        frame_pal_resized = cv2.resize(frame_pal, (width, height), interpolation=cv2.INTER_AREA)
        composite[height:, :] = frame_pal_resized
    else:
        # Use whichever frame was successfully extracted
        composite = frame_ntsc if frame_ntsc is not None else frame_pal
    
    # Save the image
    cv2.imwrite(save_path, composite)
    print(f"Frame saved to {save_path}")
    
    # Return the path to the saved image
    return save_path

if __name__ == "__main__":
    # Example usage
    if len(sys.argv) > 1:
        freq = float(sys.argv[1]) * 1e6  # Convert MHz to Hz
    else:
        freq = 5361.5e6  # Default to 5361.5 MHz
    
    capture_fpv_frame(freq)
