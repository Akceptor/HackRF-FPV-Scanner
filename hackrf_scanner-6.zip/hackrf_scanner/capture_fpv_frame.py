#!/usr/bin/env python3
"""
Quick FPV Frame Capture Utility

This script directly captures a video frame from an FPV drone at a specified frequency.
"""

import os
import sys
import time
import argparse
from video_decoder import capture_fpv_frame

def main():
    parser = argparse.ArgumentParser(description='FPV Video Frame Capture Utility')
    parser.add_argument('--frequency', type=float, default=5361.5,
                        help='Frequency in MHz (default: 5361.5 MHz)')
    parser.add_argument('--duration', type=float, default=2.0,
                        help='Capture duration in seconds (default: 2.0)')
    parser.add_argument('--output', type=str, default=None,
                        help='Output filename (default: fpv_frame_[timestamp].png)')
    args = parser.parse_args()
    
    # Calculate frequency in Hz
    frequency_hz = args.frequency * 1e6
    
    # Generate output filename if not specified
    if args.output is None:
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        output_filename = f"fpv_frame_{timestamp}.png"
    else:
        output_filename = args.output
    
    print(f"Capturing FPV video frame at {args.frequency:.2f} MHz...")
    print(f"Please ensure your drone is powered on and transmitting.")
    
    # Capture the frame
    frame_path = capture_fpv_frame(
        frequency=frequency_hz, 
        save_path=output_filename,
        duration=args.duration
    )
    
    if frame_path:
        print(f"\nSuccess! Frame saved to: {frame_path}")
        print("The image contains two processing attempts (NTSC/PAL). One may be clearer than the other.")
    else:
        print("\nFailed to capture video frame. Please check if:")
        print("1. Your drone is powered on and transmitting")
        print("2. The HackRF is properly connected")
        print("3. You have the correct frequency (try nearby frequencies)")

if __name__ == "__main__":
    main()
